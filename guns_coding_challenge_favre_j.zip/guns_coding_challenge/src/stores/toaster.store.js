
/** The namespace of the purchases store */
export const ToasterStore = "toaster";

export default {
    namespaced: true,
    state: {
        
    },
    actions: {
    },
    mutations: {
    },
    getters: {
        
    },
};